import { useEffect, useState } from 'react';
import { Stack } from 'expo-router';
import { AuthProvider } from '../src/context/AuthContext';
import { SocketProvider } from '../src/context/SocketContext';
import { BatchProvider } from '../src/context/BatchContext';
import { BrandingProvider } from '../src/context/BrandingContext';
import { initI18n } from '../src/i18n/i18n';
import AppLoader from '../src/components/AppLoader';

export default function RootLayout() {
  const [i18nReady, setI18nReady] = useState(false);

  useEffect(() => {
    initI18n().then(() => setI18nReady(true));
  }, []);

  if (!i18nReady) {
    return <AppLoader progress={5} statusText="Starting app..." />;
  }

  return (
    <AuthProvider>
      <SocketProvider>
        <BrandingProvider>
          <BatchProvider>
            <Stack screenOptions={{ headerShown: false }}>
              <Stack.Screen name="index" />
              <Stack.Screen name="(auth)/login" />
              <Stack.Screen name="(superadmin)/index" />
              <Stack.Screen
                name="(superadmin)/create-institute"
                options={{ headerShown: true, title: 'Onboard Institute' }}
              />
             <Stack.Screen name="(admin)" />
              <Stack.Screen name="(teacher)" />
              <Stack.Screen name="(student)" />
              <Stack.Screen name="(parent)/index" />
              <Stack.Screen name="(parent)/child-attendance" options={{ headerShown: true, title: "Child's Attendance" }} />
              <Stack.Screen name="(parent)/child-fees" options={{ headerShown: true, title: "Child's Fees" }} />
              <Stack.Screen name="(parent)/child-results" options={{ headerShown: true, title: "Child's Results" }} />
<Stack.Screen name="(parent)/child-homework" options={{ headerShown: true, title: "Child's Homework" }} />
            </Stack>
          </BatchProvider>
        </BrandingProvider>
      </SocketProvider>
    </AuthProvider>
  );
}